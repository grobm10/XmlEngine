#!/bin/bash

Dest01='/var/www/html/XML_Engine/xmlengine.dev/inbox/conversion/huludto/'
Dest02='/var/www/html/XML_Engine/xmlengine.dev/inbox/'
Dest01Size=`du -k $Dest01 | awk '{print $1}'`
TargetSize="100000000"
Origin01='/mnt/VoigtKampff/DTO/DTO_Metadata/FCSNYChulu/'
filesize=0
#ArrayExt=[ *.mov *.mpg *.mp4 ]

for file in `find $Origin01 -type f -name *.xml`; do
	filesize=$(du -k $file | awk '{print $1}');
	echo "Filesize: $filesize"
	(( totalsize += filesize ));
	echo "totalsize: $totalsize "
	if [[ $totalsize -le $TargetSize ]]; then 
		echo "Less than 100GB - lets move files to $Dest01"
		mv -vf "$file" "$Dest01"
	else 
		echo "More than 100GB in $Origin01 - not moving files"
	fi 
done