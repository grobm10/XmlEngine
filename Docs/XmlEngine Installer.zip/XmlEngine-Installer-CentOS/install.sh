date=$(date +"%Y%m%d")
echo "Mounting Voigt..."
mkdir /mnt/VoigtKampff
mount -t cifs //166.77.22.21/voigtkampff /mnt/VoigtKampff -o "username=idmoadmin,password=unicornbacon" && echo "Mounted..."
echo " "

echo "Creating basic folder structure..."
mkdir -p /var/www/html/XmlEngine/production/releases && echo "/var/www/html/XmlEngine/production/releases Created..."
mkdir -p /var/www/html/XmlEngine/staging/releases && echo "/var/www/html/XmlEngine/staging/releases Created..."
mkdir -p /var/www/html/XmlEngine/development/releases && echo "/var/www/html/XmlEngine/development/releases Created..."
mkdir /var/www/html/XmlEngine/production/shared && echo "/var/www/html/XmlEngine/production/shared Created..."
mkdir /var/www/html/XmlEngine/staging/shared && echo "/var/www/html/XmlEngine/staging/shared Created..."
mkdir /var/www/html/XmlEngine/development/shared && echo "/var/www/html/XmlEngine/development/shared Created..."
echo " "

echo "Mounting XML ENGINE NFS Source..."
mkdir /var/www/html/XmlEngine/NfsSource
mount -o soft,intr,rsize=8192,wsize=8192 166.77.22.94:/shares/XMLEngine /var/www/html/XmlEngine/NfsSource && echo "Mounted..."
echo " "

echo "Downloading from SVN..."
#production realease
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/Controllers /var/www/html/XmlEngine/production/releases/$date/Controllers
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/Docs /var/www/html/XmlEngine/production/releases/$date/Docs
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/Entities /var/www/html/XmlEngine/production/releases/$date/Entities
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/Models /var/www/html/XmlEngine/production/releases/$date/Models
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/resources /var/www/html/XmlEngine/production/releases/$date/resources
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/Triggers /var/www/html/XmlEngine/production/releases/$date/Triggers
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/Utils /var/www/html/XmlEngine/production/releases/$date/Utils
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd/Views /var/www/html/XmlEngine/production/releases/$date/Views
#development realease
svn co https://subversion.1515.mtvi.com/phpsites/international/Finalcutlngest/branches/currasd /var/www/html/XmlEngine/development/releases/$date
echo " "

echo "Coping shared folder structure from source and assets folder..."
cp -R ./assets/LogsStructure /var/www/html/XmlEngine/production/shared/logs && echo "production LogsStructure copied..."
cp -R ./assets/InboxStructure /var/www/html/XmlEngine/staging/shared/inbox && echo "staging InboxStructure copied..."
cp -R ./assets/OutboxStructure /var/www/html/XmlEngine/staging/shared/outbox && echo "staging OutboxStructure copied..."
cp -R ./assets/LogsStructure /var/www/html/XmlEngine/staging/shared/logs && echo "staging LogsStructure copied..."
cp -R ./assets/InboxStructure /var/www/html/XmlEngine/development/shared/inbox && echo "development InboxStructure copied..."
cp -R ./assets/OutboxStructure /var/www/html/XmlEngine/development/shared/outbox && echo "development OutboxStructure copied..."
cp -R ./assets/LogsStructure /var/www/html/XmlEngine/development/shared/logs && echo "development LogsStructure copied..."
echo " "

echo "Adding SymbLinks for production inbox..."
ln -s /var/www/html/XmlEngine/NfsSource/XmlEngine_Assets/inbox /var/www/html/XmlEngine/production/releases/$date/inbox && echo "production Inbox symblink added..."
ln -s /var/www/html/XmlEngine/NfsSource/XmlEngine_Assets/outbox /var/www/html/XmlEngine/production/releases/$date/outbox && echo "production Outbox symblink added..."
ln -s /var/www/html/XmlEngine/NfsSource/XmlEngine_Assets/inbox /var/www/html/XmlEngine/production/shared/inbox && echo "production Shared Inbox symblink added..."
ln -s /var/www/html/XmlEngine/NfsSource/XmlEngine_Assets/outbox /var/www/html/XmlEngine/production/shared/outbox && echo "production Shared Outbox symblink added..."
echo " "

echo "Coping root folder files from dev to prod..."
cp /var/www/html/XmlEngine/development/releases/$date/index.php /var/www/html/XmlEngine/production/releases/$date/index.php && echo "index.php copied..."
cp /var/www/html/XmlEngine/development/releases/$date/siteConfig.php /var/www/html/XmlEngine/production/releases/$date/siteConfig.php && echo "siteConfig.php copied..."
echo " "

echo "Adding SymbLinks..."
ln -s /var/www/html/XmlEngine/production/shared/logs /var/www/html/XmlEngine/production/releases/$date/logs && echo "production Logs symblink added..."
ln -s /var/www/html/XmlEngine/development/shared/inbox /var/www/html/XmlEngine/development/releases/$date/inbox && echo "development Inbox symblink added..."
ln -s /var/www/html/XmlEngine/development/shared/outbox /var/www/html/XmlEngine/development/releases/$date/outbox && echo "development Outbox symblink added..."
ln -s /var/www/html/XmlEngine/development/shared/logs /var/www/html/XmlEngine/development/releases/$date/logs && echo "development Logs symblink added..."
ln -s /var/www/html/XmlEngine/production/releases/$date /var/www/html/XmlEngine/production/current && echo "production current symblink added..."
ln -s /var/www/html/XmlEngine/development/releases/$date /var/www/html/XmlEngine/development/current && echo "development current symblink added..."
echo " "

echo "Coping virtual-host file from assets..."
cp -R /etc/httpd/conf/httpd.conf /etc/httpd/conf/httpd.conf.old && echo "httpd.conf.old created..."
cp -R -f ./assets/httpd.conf /etc/httpd/conf/httpd.conf && echo "httpd.conf replaced..."
echo " "

echo "Coping svn scripts from assets..."
cp -R ./assets/SvnScripts /var/www/html/XmlEngine/SvnScripts && echo "SvnScripts copied..."
echo " "

echo "Creating Databases..."
mysql -uroot -punicornbacon -e "CREATE DATABASE xmle_dev; CREATE DATABASE xmle_pro;" && echo "Databases created..."
echo " "

echo "Importing Database..."
mysql -uroot -punicornbacon xmle_dev < ./assets/xmle_dev.sql && echo "xmle_dev imported..."
mysql -uroot -punicornbacon xmle_pro < ./assets/xmle_pro.sql && echo "xmle_pro imported..."
echo " "

echo "Changing owner and restarting apache..."
chown -R www-data:www-data /var/www/html/ && echo "/var/www/html/ owner changed to www-data..."
service httpd restart && echo "Apache restarted..."
echo " "

echo "DONE"
