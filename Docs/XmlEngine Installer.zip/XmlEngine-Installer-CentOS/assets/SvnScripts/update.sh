date=$(date +"%Y%m%d")
#production realease
svn update /var/www/html/XmlEngine/production/releases/$date/Controllers
svn update /var/www/html/XmlEngine/production/releases/$date/Docs
svn update /var/www/html/XmlEngine/production/releases/$date/Entities
svn update /var/www/html/XmlEngine/production/releases/$date/Models
svn update /var/www/html/XmlEngine/production/releases/$date/resources
svn update /var/www/html/XmlEngine/production/releases/$date/Triggers
svn update /var/www/html/XmlEngine/production/releases/$date/Utils
svn update /var/www/html/XmlEngine/production/releases/$date/Views
#development realease
svn update /var/www/html/XmlEngine/development/releases/$date
