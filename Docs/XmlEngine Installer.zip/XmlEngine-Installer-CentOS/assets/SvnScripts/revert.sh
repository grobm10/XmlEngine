date=$(date +"%Y%m%d")
#production realease
svn revert -R /var/www/html/XmlEngine/production/releases/$date/Controllers
svn revert -R /var/www/html/XmlEngine/production/releases/$date/Docs
svn revert -R /var/www/html/XmlEngine/production/releases/$date/Entities
svn revert -R /var/www/html/XmlEngine/production/releases/$date/Models
svn revert -R /var/www/html/XmlEngine/production/releases/$date/resources
svn revert -R /var/www/html/XmlEngine/production/releases/$date/Triggers
svn revert -R /var/www/html/XmlEngine/production/releases/$date/Utils
svn revert -R /var/www/html/XmlEngine/production/releases/$date/Views
#development realease
svn revert -R /var/www/html/XmlEngine/development/releases/$date/Controllers
svn revert -R /var/www/html/XmlEngine/development/releases/$date/Docs
svn revert -R /var/www/html/XmlEngine/development/releases/$date/Entities
svn revert -R /var/www/html/XmlEngine/development/releases/$date/Models
svn revert -R /var/www/html/XmlEngine/development/releases/$date/resources
svn revert -R /var/www/html/XmlEngine/development/releases/$date/Triggers
svn revert -R /var/www/html/XmlEngine/development/releases/$date/Utils
svn revert -R /var/www/html/XmlEngine/development/releases/$date/Views
svn revert /var/www/html/XmlEngine/development/releases/$date/siteConfig.php
svn revert /var/www/html/XmlEngine/development/releases/$date/index.php